﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using classSchool;



namespace schoolUse
{
    class Program
    {
        public static Class1 cls = new Class1();
        static void Main(string[] args)
        {
            List<Mark> marks = new List<Mark>();
            List<Students> students = new List<Students>
            {
                new Students(2018,218,"Лебедев Николай Романович"),
                new Students(2019,219,"Демидов Никита Русланович"),
                new Students(2020,220,"Васильев Константин Сергеевич"),
                new Students(2021,221,"Павлова Вера Савельевна"),
                new Students(2022,222,"Бакина Рита Федоровна")
            };
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.01.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.02.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.03.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.04.2022"), students));

            foreach (Mark m in marks)

            {
            Console.WriteLine($"{m.date.ToString("dd.MM.yyyy")}\t{m.Estimation} - {m.student.fio}");
            }
            Console.WriteLine();
            foreach (int i in cls.GetCountTruancy(marks))
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            foreach (int i in cls.GetCountDisease(marks))
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            foreach (Students std in students)
            {
                Console.WriteLine(cls.GetStudNumber(std.year, std.group, std.fio));
            }
            Console.WriteLine();
            Console.WriteLine(cls.MinAVG(new string[6] { "4", "5", "5", "б", "п", " " }));
            Console.ReadKey();


        }
    }
}